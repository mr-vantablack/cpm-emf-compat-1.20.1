package dev.cpmemfcompat.render;

import dev.cpmemfcompat.CpmEmfCompat;
import dev.cpmemfcompat.bridge.CpmBridge;
import dev.cpmemfcompat.bridge.EmfBridge;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.client.event.RenderPlayerEvent;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Reorders only CPM's binding around vanilla/EMF animation setup.
 *
 * Normal order:
 *   CPM Pre -> vanilla setupAnim -> EMF -> render -> CPM Post
 *
 * Compat order:
 *   CPM Pre
 *   -> CPM Post (temporary swap-out)
 *   -> vanilla setupAnim on original parts
 *   -> EMF animation on original parts
 *   -> CPM Pre (swap-in, now using the EMF pose as base)
 *   -> render
 *   -> normal CPM Post
 */
public final class RenderCoordinator {
    private static final ThreadLocal<Deque<PlayerRenderContext>> PENDING =
            ThreadLocal.withInitial(ArrayDeque::new);

    private static final AtomicBoolean MISSED_HOOK_WARNING = new AtomicBoolean(false);
    private static final AtomicBoolean SUSPEND_FAILURE_WARNING = new AtomicBoolean(false);
    private static final AtomicBoolean RESUME_FAILURE_WARNING = new AtomicBoolean(false);

    private RenderCoordinator() {
    }

    public static void begin(RenderPlayerEvent.Pre event) {
        // CPM's NORMAL-priority Pre callback has already run when this LOWEST
        // listener is called.
        if (event.isCanceled()) return;
        if (!CpmBridge.available()) return;

        PlayerRenderContext context = PlayerRenderContext.from(event);

        // Do not touch ordinary/non-EMF player models. This keeps the compat
        // effectively dormant unless the active player model really has CEM animation.
        if (!EmfBridge.isAnimated(context.model())) return;

        try {
            CpmBridge.suspend(context);
            PENDING.get().push(context);
        } catch (Throwable t) {
            if (SUSPEND_FAILURE_WARNING.compareAndSet(false, true)) {
                CpmEmfCompat.LOGGER.error(
                        "Failed to temporarily unbind CPM. Further identical errors are suppressed.", t
                );
            }
        }
    }

    /** Called by the LivingEntityRenderer mixin after vanilla setupAnim. */
    public static void resumeIfPending(LivingEntity entity, String hookName) {
        if (!(entity instanceof Player player)) return;

        Deque<PlayerRenderContext> stack = PENDING.get();
        PlayerRenderContext context = stack.peek();
        if (context == null || context.player() != player) return;

        // Remove first. If anything below fails, leaving CPM swapped OUT is safer
        // than leaking a swapped-IN model into later renders.
        stack.pop();
        if (stack.isEmpty()) PENDING.remove();

        try {
            boolean manuallyAnimated = EmfBridge.applyAnimation(player, context.model());
            CpmEmfCompat.LOGGER.trace(
                    "Resuming CPM after {} for {} (manual EMF animation: {})",
                    hookName, player.getGameProfile().getName(), manuallyAnimated
            );
        } finally {
            try {
                CpmBridge.resume(context);
            } catch (Throwable t) {
                if (RESUME_FAILURE_WARNING.compareAndSet(false, true)) {
                    CpmEmfCompat.LOGGER.error(
                            "Failed to rebind CPM after EMF animation. Further identical errors are suppressed.", t
                    );
                }
            }
        }
    }

    /**
     * Safety cleanup. A remaining context means neither mixin injection fired.
     * The real CPM Post callback has already run by LOWEST Post priority and CPM
     * is therefore left swapped out, which is the safest state for the next frame.
     */
    public static void finish(RenderPlayerEvent.Post event) {
        Deque<PlayerRenderContext> stack = PENDING.get();
        if (stack.isEmpty()) return;

        Player player = event.getEntity();
        PlayerRenderContext context = stack.peek();
        if (context != null && context.player() == player) {
            stack.pop();
            if (stack.isEmpty()) PENDING.remove();

            if (MISSED_HOOK_WARNING.compareAndSet(false, true)) {
                CpmEmfCompat.LOGGER.error(
                        "Neither post-setupAnim nor pre-render fallback hook fired for the player model. " +
                        "This frame was rendered without the CPM rebind. Check other renderer/core mods."
                );
            }
        }
    }
}
