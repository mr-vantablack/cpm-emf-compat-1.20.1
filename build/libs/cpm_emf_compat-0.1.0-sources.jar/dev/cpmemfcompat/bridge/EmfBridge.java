package dev.cpmemfcompat.bridge;

import dev.cpmemfcompat.CpmEmfCompat;
import net.minecraft.client.model.EntityModel;
import net.minecraft.world.entity.Entity;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

/**
 * Reflection bridge to EMF's public animation API.
 *
 * The important API calls are:
 *   isModelAnimatedByEMF(EntityModel)
 *   emfEntityOf(Entity)
 *   animateModelForEntity(EMFEntity, EntityModel, boolean)
 *
 * Keeping these reflective makes the compat jar less tightly coupled to a
 * single EMF build while still using EMF's supported public API.
 */
public final class EmfBridge {
    private static final String EMF_API = "traben.entity_model_features.EMFAnimationApi";

    private static volatile boolean initAttempted;
    private static volatile boolean available;
    private static volatile boolean manualAnimationAvailable;

    private static Method isModelAnimated;
    private static Method emfEntityOf;
    private static Method animateModelForEntity;

    private EmfBridge() {
    }

    public static boolean isAnimated(EntityModel<?> model) {
        ensureInitialized();
        if (!available) return false;

        try {
            return Boolean.TRUE.equals(isModelAnimated.invoke(null, model));
        } catch (Throwable t) {
            CpmEmfCompat.LOGGER.error("EMF isModelAnimatedByEMF call failed; skipping compat for this render.", unwrap(t));
            return false;
        }
    }

    /**
     * Explicitly asks EMF to materialize the custom animation onto the original
     * model after vanilla setupAnim. This makes the ordering deterministic even
     * if EMF's own mixin callback happens after ours.
     *
     * @return true when the public API says it animated the model. False is not
     *         fatal: EMF may already have animated it through its normal hook.
     */
    public static boolean applyAnimation(Entity entity, EntityModel<?> model) {
        ensureInitialized();
        if (!manualAnimationAvailable) return false;

        try {
            Object emfEntity = emfEntityOf.invoke(null, entity);
            Object result = animateModelForEntity.invoke(null, emfEntity, model, false);
            return Boolean.TRUE.equals(result);
        } catch (Throwable t) {
            CpmEmfCompat.LOGGER.error("EMF manual animation API call failed; CPM will still be rebound.", unwrap(t));
            return false;
        }
    }

    private static synchronized void ensureInitialized() {
        if (initAttempted) return;
        initAttempted = true;

        try {
            Class<?> apiClass = Class.forName(EMF_API);
            isModelAnimated = apiClass.getMethod("isModelAnimatedByEMF", EntityModel.class);
            available = true;

            // Manual animation is optional. If an older EMF lacks this exact
            // overload, the ordering shim still works and relies on EMF's own hook.
            try {
                emfEntityOf = apiClass.getMethod("emfEntityOf", Entity.class);
                animateModelForEntity = findEntityModelAnimationMethod(apiClass);
                manualAnimationAvailable = emfEntityOf != null && animateModelForEntity != null;
            } catch (Throwable ignored) {
                manualAnimationAvailable = false;
            }

            CpmEmfCompat.LOGGER.info(
                    "Connected to EMF animation API (manual animation call available: {})",
                    manualAnimationAvailable
            );
        } catch (Throwable t) {
            available = false;
            manualAnimationAvailable = false;
            CpmEmfCompat.LOGGER.error(
                    "Could not connect to EMFAnimationApi. Compat will stay disabled.", t
            );
        }
    }

    private static Method findEntityModelAnimationMethod(Class<?> apiClass) {
        for (Method method : apiClass.getMethods()) {
            if (!method.getName().equals("animateModelForEntity")) continue;
            if (!Modifier.isStatic(method.getModifiers())) continue;

            Class<?>[] p = method.getParameterTypes();
            if (p.length == 3
                    && EntityModel.class.equals(p[1])
                    && (boolean.class.equals(p[2]) || Boolean.class.equals(p[2]))) {
                return method;
            }
        }
        return null;
    }

    private static Throwable unwrap(Throwable t) {
        if (t instanceof InvocationTargetException ite && ite.getCause() != null) {
            return ite.getCause();
        }
        return t;
    }
}
