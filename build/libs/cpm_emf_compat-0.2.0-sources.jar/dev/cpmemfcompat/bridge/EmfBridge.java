package dev.cpmemfcompat.bridge;

import dev.cpmemfcompat.CpmEmfCompat;
import net.minecraft.client.model.EntityModel;
import net.minecraft.world.entity.Entity;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Reflection bridge to EMF.
 *
 * v0.2 intentionally does NOT require EMFAnimationApi.emfEntityOf(Entity).
 * Some EMF builds expose isModelAnimatedByEMF but not that helper. The actual
 * Minecraft Entity is already mixed into EMF's EMFEntity interface, so it can
 * normally be supplied directly to animateModelForEntity(...).
 *
 * There is also a fallback which gets EMF's root model and invokes animate()
 * directly. That path is useful for older EMF API revisions while rendering,
 * because EMF has already established its per-entity animation context.
 */
public final class EmfBridge {
    private static final String EMF_API = "traben.entity_model_features.EMFAnimationApi";

    private static volatile boolean initAttempted;
    private static volatile boolean available;

    private static Method isModelAnimated;
    private static Method animateModelForEntity;
    private static Method emfEntityOf;
    private static Method apiVersion;
    private static Method getCurrentEntity;

    private static final AtomicBoolean FIRST_APPLY_LOG = new AtomicBoolean(false);
    private static final AtomicBoolean FIRST_DIRECT_ROOT_LOG = new AtomicBoolean(false);

    private EmfBridge() {
    }

    public enum ApplyResult {
        API,
        ROOT_FALLBACK,
        NOT_APPLIED
    }

    public static boolean isAnimated(EntityModel<?> model) {
        ensureInitialized();
        if (!available || isModelAnimated == null) return false;

        try {
            return Boolean.TRUE.equals(isModelAnimated.invoke(null, model));
        } catch (Throwable t) {
            CpmEmfCompat.LOGGER.error(
                    "EMF isModelAnimatedByEMF call failed; skipping compat for this render.",
                    unwrap(t)
            );
            return false;
        }
    }

    /**
     * Materializes EMF/CEM animation onto the original player model BEFORE CPM
     * is rebound, so CPM can copy the finished EMF pose as its base pose.
     */
    public static ApplyResult applyAnimation(Entity entity, EntityModel<?> model) {
        ensureInitialized();
        if (!available) return ApplyResult.NOT_APPLIED;

        // Preferred path: EMF's animation API. Do not require emfEntityOf().
        if (animateModelForEntity != null) {
            try {
                Class<?> emfEntityType = animateModelForEntity.getParameterTypes()[0];
                Object emfEntity = adaptEntity(entity, emfEntityType);

                if (emfEntity != null) {
                    Object result = animateModelForEntity.invoke(null, emfEntity, model, false);
                    boolean animated = Boolean.TRUE.equals(result);

                    if (FIRST_APPLY_LOG.compareAndSet(false, true)) {
                        CpmEmfCompat.LOGGER.info(
                                "First EMF animation transfer: apiMethod={}, entityClass={}, requiredEntityType={}, result={}",
                                signature(animateModelForEntity),
                                entity.getClass().getName(),
                                emfEntityType.getName(),
                                animated
                        );
                    }

                    if (animated) return ApplyResult.API;
                } else if (FIRST_APPLY_LOG.compareAndSet(false, true)) {
                    CpmEmfCompat.LOGGER.warn(
                            "EMF animateModelForEntity exists, but player {} is not compatible with first parameter {}",
                            entity.getClass().getName(), emfEntityType.getName()
                    );
                }
            } catch (Throwable t) {
                CpmEmfCompat.LOGGER.error(
                        "EMF animateModelForEntity call failed; trying direct root fallback.",
                        unwrap(t)
                );
            }
        }

        // Fallback for EMF versions where the public animation method is absent
        // or returned false. During LivingEntityRenderer.render EMF has normally
        // already mounted the active entity context, so root.animate() can run.
        if (animateRootDirectly(model)) {
            return ApplyResult.ROOT_FALLBACK;
        }

        return ApplyResult.NOT_APPLIED;
    }

    private static Object adaptEntity(Entity entity, Class<?> requiredType) throws Throwable {
        // EMF applies its EMFEntity interface to vanilla Entity via mixin.
        if (requiredType.isInstance(entity)) {
            return entity;
        }

        // Optional compatibility with API versions that provide a converter.
        if (emfEntityOf != null) {
            Object converted = emfEntityOf.invoke(null, entity);
            if (converted != null && requiredType.isInstance(converted)) {
                return converted;
            }
        }

        return null;
    }

    private static boolean animateRootDirectly(EntityModel<?> model) {
        try {
            Object root = findRoot(model);
            if (root == null) return false;

            Method animate = findZeroArgMethod(root.getClass(), "animate");
            if (animate == null) return false;

            animate.invoke(root);

            if (FIRST_DIRECT_ROOT_LOG.compareAndSet(false, true)) {
                CpmEmfCompat.LOGGER.info(
                        "EMF direct-root fallback executed using {} on {}",
                        signature(animate), root.getClass().getName()
                );
            }
            return true;
        } catch (Throwable t) {
            if (FIRST_DIRECT_ROOT_LOG.compareAndSet(false, true)) {
                CpmEmfCompat.LOGGER.error(
                        "EMF direct-root animation fallback failed.", unwrap(t)
                );
            }
            return false;
        }
    }

    private static Object findRoot(EntityModel<?> model) throws Throwable {
        // IEMFModel is mixed into the actual EntityModel implementation. Search
        // the runtime class/interfaces rather than linking against EMF classes.
        Method getter = findZeroArgMethod(model.getClass(), "emf$getEMFRootModel");
        if (getter != null) return getter.invoke(model);

        for (Class<?> itf : model.getClass().getInterfaces()) {
            getter = findZeroArgMethod(itf, "emf$getEMFRootModel");
            if (getter != null) return getter.invoke(model);
        }
        return null;
    }

    private static synchronized void ensureInitialized() {
        if (initAttempted) return;
        initAttempted = true;

        try {
            Class<?> apiClass = Class.forName(EMF_API);

            isModelAnimated = findMethod(apiClass, "isModelAnimatedByEMF", m -> {
                Class<?>[] p = m.getParameterTypes();
                return p.length == 1 && EntityModel.class.isAssignableFrom(p[0]);
            });

            animateModelForEntity = findMethod(apiClass, "animateModelForEntity", m -> {
                if (!Modifier.isStatic(m.getModifiers())) return false;
                Class<?>[] p = m.getParameterTypes();
                return p.length == 3
                        && EntityModel.class.isAssignableFrom(p[1])
                        && (p[2] == boolean.class || p[2] == Boolean.class);
            });

            emfEntityOf = findMethod(apiClass, "emfEntityOf", m -> {
                Class<?>[] p = m.getParameterTypes();
                return p.length == 1 && p[0].isAssignableFrom(Entity.class);
            });

            apiVersion = findZeroArgMethod(apiClass, "getApiVersion");
            getCurrentEntity = findZeroArgMethod(apiClass, "getCurrentEntity");

            available = isModelAnimated != null;

            Object version = null;
            if (apiVersion != null) {
                try {
                    version = apiVersion.invoke(null);
                } catch (Throwable ignored) {
                }
            }

            CpmEmfCompat.LOGGER.info(
                    "Connected to EMF animation bridge: apiVersion={}, isAnimated={}, animateForEntity={}, emfEntityOf={}, currentEntity={}",
                    version == null ? "unknown" : version,
                    signature(isModelAnimated),
                    signature(animateModelForEntity),
                    signature(emfEntityOf),
                    signature(getCurrentEntity)
            );

            if (animateModelForEntity == null) {
                CpmEmfCompat.LOGGER.warn(
                        "EMF public animateModelForEntity method was not found. Direct root-animation fallback will be used."
                );
            }
        } catch (Throwable t) {
            available = false;
            CpmEmfCompat.LOGGER.error(
                    "Could not connect to EMFAnimationApi. Compat will stay disabled.", t
            );
        }
    }

    private interface MethodPredicate {
        boolean test(Method method);
    }

    private static Method findMethod(Class<?> type, String name, MethodPredicate predicate) {
        // getDeclaredMethods catches API methods that are not exposed through
        // getMethods() in some transformed/interface builds.
        for (Method method : type.getDeclaredMethods()) {
            if (!method.getName().equals(name)) continue;
            if (!predicate.test(method)) continue;
            makeAccessible(method);
            return method;
        }
        for (Method method : type.getMethods()) {
            if (!method.getName().equals(name)) continue;
            if (!predicate.test(method)) continue;
            makeAccessible(method);
            return method;
        }
        return null;
    }

    private static Method findZeroArgMethod(Class<?> type, String name) {
        return findMethod(type, name, m -> m.getParameterCount() == 0);
    }

    private static void makeAccessible(Method method) {
        try {
            method.setAccessible(true);
        } catch (Throwable ignored) {
            // Public methods remain invokable without this.
        }
    }

    private static String signature(Method method) {
        if (method == null) return "<missing>";
        return method.getDeclaringClass().getName() + "#" + method.getName()
                + Arrays.toString(method.getParameterTypes());
    }

    private static Throwable unwrap(Throwable t) {
        if (t instanceof InvocationTargetException ite && ite.getCause() != null) {
            return ite.getCause();
        }
        return t;
    }
}
